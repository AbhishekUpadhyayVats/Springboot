package com.lpu.StudentManagementSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.lpu.StudentManagementSystem.entity.Sms;
import com.lpu.StudentManagementSystem.exception.SmsNotFoundException;
import com.lpu.StudentManagementSystem.repository.SmsRepository;

@Service
public class SmsUserDetailService implements UserDetailsService{
	
	@Autowired
	private SmsRepository smsRepo;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Sms sms = smsRepo.findByEmail(email);
		if(sms == null) {
			throw new SmsNotFoundException("Student with email:" + email + " does not exists");
		}
		return new SmsUserDetails(sms);
	}

}
